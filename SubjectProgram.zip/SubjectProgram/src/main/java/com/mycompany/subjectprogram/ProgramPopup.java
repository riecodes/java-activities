package com.mycompany.subjectprogram;

public class ProgramPopup extends javax.swing.JDialog {
    
    private String program1;
    private String program2;
    private boolean confirmed = false; // To track if the user clicked "OK"
    
    public ProgramPopup(java.awt.Frame parent, boolean modal, String program1, String program2) {
        super(parent, modal);
        initComponents();
        
        // Initialize text fields with passed values
        progText1.setText(program1);
        progText2.setText(program2);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        progLabel1 = new javax.swing.JLabel();
        progText1 = new javax.swing.JTextField();
        progLabel2 = new javax.swing.JLabel();
        progText2 = new javax.swing.JTextField();
        okBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        progLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        progLabel1.setText("Program 1:");

        progText1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                progText1ActionPerformed(evt);
            }
        });

        progLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        progLabel2.setText("Program 2:");

        progText2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                progText2ActionPerformed(evt);
            }
        });

        okBtn.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        okBtn.setText("OK");
        okBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                okBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(322, Short.MAX_VALUE)
                .addComponent(okBtn)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(progLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(progLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(progText1)
                    .addComponent(progText2, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(113, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(progText1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(progLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(progText2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(progLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(101, 101, 101)
                .addComponent(okBtn)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void progText1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_progText1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_progText1ActionPerformed

    private void progText2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_progText2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_progText2ActionPerformed

    private void okBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_okBtnActionPerformed
        // TODO add your handling code here:

        // Get the values from the text fields
        program1 = progText1.getText();
        program2 = progText2.getText();
        confirmed = true; // Mark as confirmed
        dispose(); // Close the dialog

    }//GEN-LAST:event_okBtnActionPerformed

    // Getters for programs
    public String getProgram1() { return program1; }
    public String getProgram2() { return program2; }
    public boolean isConfirmed() { return confirmed; }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton okBtn;
    private javax.swing.JLabel progLabel1;
    private javax.swing.JLabel progLabel2;
    private javax.swing.JTextField progText1;
    private javax.swing.JTextField progText2;
    // End of variables declaration//GEN-END:variables
}
