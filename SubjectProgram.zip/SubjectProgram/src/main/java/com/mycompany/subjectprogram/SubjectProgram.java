package com.mycompany.subjectprogram;

import com.mycompany.subjectprogram.SubjectPopup;

public class SubjectProgram extends javax.swing.JDialog {
    
    private String subject1 = ""; // Store subjects
    private String subject2 = "";
    private String subject3 = "";
    
    private String program1 = "";
    private String program2 = "";
    
    private boolean confirmed = false;
    
    public SubjectProgram(java.awt.Frame parent, boolean modal) {
        super(parent, modal);

        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        subject = new javax.swing.JLabel();
        program = new javax.swing.JLabel();
        subjectBtn = new javax.swing.JButton();
        programBtn = new javax.swing.JButton();
        viewBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        subject.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        subject.setText("Subject:");

        program.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        program.setText("Program:");

        subjectBtn.setText("+");
        subjectBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subjectBtnActionPerformed(evt);
            }
        });

        programBtn.setText("+");
        programBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                programBtnActionPerformed(evt);
            }
        });

        viewBtn.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        viewBtn.setText("View");
        viewBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(145, 145, 145)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(program, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
                            .addComponent(subject, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(programBtn)
                            .addComponent(subjectBtn)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(viewBtn)))
                .addContainerGap(163, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(subject)
                    .addComponent(subjectBtn))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(program))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(programBtn)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addComponent(viewBtn)
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void programBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_programBtnActionPerformed
        // TODO add your handling code here:
        
        // Open the ProgramPopup dialog
        ProgramPopup popup = new ProgramPopup(new javax.swing.JFrame(), true, program1, program2);
        popup.setVisible(true); // Show the popup

        // Check if the user clicked "OK" (popup is confirmed)
        if (popup.isConfirmed()) {
            program1 = popup.getProgram1();
            program2 = popup.getProgram2();

            // Display program or process them as needed
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Programs Entered:\n1. " + program1 + "\n2. " + program2);
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "No programs were entered.");
        }
    }//GEN-LAST:event_programBtnActionPerformed

    private void subjectBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subjectBtnActionPerformed
        // TODO add your handling code here:
        
        // Open the SubjectPopup dialog
        SubjectPopup popup = new SubjectPopup(new javax.swing.JFrame(), true, subject1, subject2, subject3);
        popup.setVisible(true); // Show the popup

        // Check if the user clicked "OK" (popup is confirmed)
        if (popup.isConfirmed()) {
            subject1 = popup.getSubject1();
            subject2 = popup.getSubject2();
            subject3 = popup.getSubject3();

            // Display subjects or process them as needed
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Subjects Entered:\n1. " + subject1 + "\n2. " + subject2 + "\n3. " + subject3);
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "No subjects were entered.");
        }
    
    }//GEN-LAST:event_subjectBtnActionPerformed

    private void viewBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewBtnActionPerformed
        // TODO add your handling code here:
        
        // Create and show the ViewPopup dialog
        ViewPopup viewPopup = new ViewPopup(new javax.swing.JFrame(), true, subject1, subject2, subject3, program1, program2);
        viewPopup.setVisible(true);
        
        
    }//GEN-LAST:event_viewBtnActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            
            // Set the FlatLaf look and feel
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
        }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SubjectProgram.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SubjectProgram.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SubjectProgram.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SubjectProgram.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SubjectProgram dialog = new SubjectProgram(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel program;
    private javax.swing.JButton programBtn;
    private javax.swing.JLabel subject;
    private javax.swing.JButton subjectBtn;
    private javax.swing.JButton viewBtn;
    // End of variables declaration//GEN-END:variables
}
